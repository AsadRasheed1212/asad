import React from 'react'
import LoadingAnimation from './LoadingAnimation'

export default { title: 'loading' }

export const loadingAnimation = () => {
  return (
    <LoadingAnimation />
  )
}
